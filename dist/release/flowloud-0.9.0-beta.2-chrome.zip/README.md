# Flowloud / 流声扩展

这是 Flowloud 的 Edge / Chrome Manifest V3 扩展源码。它负责识别网页正文，并通过系统语音、浏览器模型、本地 Qwen 或 OpenAI 兼容 Provider 朗读；同时提供 Popup、播放期间的悬浮播放器、页面导览、正文高亮、音色库和设置中心。

完整的项目定位、本地网关说明和协议见仓库根目录的 `README.md`。

## 功能

- 识别论坛帖子、文章、小说章节和普通网页正文。
- 支持 Discourse、Flarum、NodeBB，兼容 XenForo 当前页和通用正文回退。
- Popup 提供开始/暂停、上一句/下一句、网页点读、配音策略和本页作者音色调整。
- 网页悬浮播放器在用户主动朗读后出现，展示文本识别、模型加载、合成、播放、暂停和错误状态。
- 悬浮播放器支持完整/最小化显示、拖动吸附、位置记忆和回到朗读位置；Popup 中的“网页悬浮窗”开关负责显示或隐藏。
- 完整状态的长台词会与正文当前词同步滑动，不使用脱离朗读进度的循环跑马灯。
- 正文保留当前句、作者、音色、进度、逐词高亮和滚动跟随提示。
- 网页点读默认关闭，并跳过链接、按钮、输入框、媒体和代码等交互内容。
- 设置中心支持阅读聚焦、主题、逐词颜色/光晕/速度、全局作者配音和音色管理。
- 音色工作室支持麦克风录制和批量上传音频。
- 来源标签页关闭后停止对应的合成和播放。

页面导览可按标题、区域、段落、列表、表格、链接、按钮、表单与图片导航和朗读，但不点击、提交或修改网页，也不能替代系统读屏软件。

## Provider 与模型

当前内置 Provider V3：

```text
browser-system       默认，使用 chrome.tts，无需配置
browser-model        固定 revision 的 VITS / Kokoro，本地推理
local-qwen           127.0.0.1:7811，需要配对令牌
openai-compatible    用户配置的 HTTPS /v1/audio/speech
```

Provider V3 按能力声明 `health`、`voices`、`synthesize`、`play`、`pause`、`resume`、`cancel` 与 `modelManagement`，Provider 只实现适用能力。音色 ID 使用 `providerId:voiceId` 命名空间。

## 快速加载

在仓库根目录运行：

```powershell
.\package-extension.ps1
```

然后在正常使用的 Edge 中：

1. 打开 `edge://extensions/`。
2. 开启“开发人员模式”。
3. 点击“加载解压缩的扩展”。
4. 选择 `dist\Flowloud-Edge`。
5. 刷新已经打开的网页。

更新时重新运行打包脚本，在扩展管理页点击“重新加载”，再刷新目标网页即可。

## 第一次使用

1. 打开文章或论坛帖子；新安装默认直接使用浏览器系统语音。
2. 如需本地 Qwen，再启动网关、复制托盘配对令牌并在“朗读引擎”中粘贴。
3. 点击 Edge 工具栏中的扩展图标。
4. 等待正文识别完成，然后点击“开始朗读”。
5. Popup 关闭后朗读仍会继续；开启“网页悬浮窗”时，可在网页右下角继续控制播放。

快捷键 `Alt+O` 用于播放或暂停当前页面。

只有本地 Qwen 首版支持音色克隆。可以在切换到本地 Qwen 后进入“设置 → 音色与克隆”录制或上传音色，再通过全局策略或“本页配音”分配。

## 基础无障碍

- 使用原生按钮、输入框和选择框，支持键盘焦点。
- 播放和错误状态通过 `role="status"`/`aria-live` 提供简短播报。
- Popup 定时刷新时保留当前焦点，不在每次轮询时重新播报整个页面。
- 支持减少动效和 Windows 强制颜色模式。
- 网页跟随和高亮不主动抢占页面焦点。
- 控制按钮提供可见焦点和适合触控的尺寸。

## 隐私

- 网页正文和参考音频默认只发送到本机回环地址。
- 扩展不包含远程脚本。
- 音频导入的转写依赖浏览器提供的语音识别能力，其可用性和数据处理方式取决于 Edge 与系统配置。

## 开发测试

使用项目提供的 Node.js 运行时或本机 Node.js：

```powershell
cd extension
npm test
```

浏览器测试页面位于 `tests/browser/`。Popup 的并排状态预览位于 `popup-lab.html`，它复用生产渲染代码，不是静态图片原型。

## 主要目录

- `background.js`：Popup/标签页消息路由、offscreen 生命周期和来源标签页清理。
- `content/reader.js`：正文识别、播放队列、网页悬浮播放器和高亮。
- `popup.*`、`popup-view.js`：工具栏 Popup 与本页配音界面。
- `voice-studio.*`、`settings-center.js`：设置中心、录音、音频导入和音色库。
- `offscreen.js`：音频合成和播放。
- `shared/`：提取、Provider、音色分配、时间线和共享状态。
- `tests/`：单元、契约和浏览器 harness。
